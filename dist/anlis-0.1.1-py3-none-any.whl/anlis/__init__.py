# -*- coding: utf-8 -*-
"""anlis"""
__copyright__ = ("Copyright (c) 2023 https://github.com/dxstiny")

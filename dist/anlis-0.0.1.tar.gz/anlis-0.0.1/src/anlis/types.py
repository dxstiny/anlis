from typing import Callable

Function = Callable[[float], float]

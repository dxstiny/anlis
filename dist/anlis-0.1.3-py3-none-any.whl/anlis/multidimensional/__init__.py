# -*- coding: utf-8 -*-
"""a toolset for dealing with multidimensional calculus"""
__copyright__ = ("Copyright (c) 2023 https://github.com/dxstiny")

# -*- coding: utf-8 -*-
"""a toolset for dealing with sequences & series"""
__copyright__ = ("Copyright (c) 2023 https://github.com/dxstiny")


from anlis.series.series import *
